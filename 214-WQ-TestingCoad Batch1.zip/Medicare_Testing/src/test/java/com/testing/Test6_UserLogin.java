package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test6_UserLogin {
  @Test
  public void userLogin() throws InterruptedException {
	  
	//Setting up the driver and getting the website
	    String driver_path="D:\\phase 5\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driver_path);
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:4200/user");
		
		
		//sending the user name
		WebElement username = driver.findElement(By.id("username"));
				username.sendKeys("akshayvs");
				
		//sending the password
		WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
		password.sendKeys("Krishna");
		
		//click Submit
		WebElement submit = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div/div/button"));
		submit.click();
	
		Thread.sleep(1000);
		WebElement confirm = driver.findElement(By.xpath("/html/body/div/div/div[6]/button[1]"));
		confirm.click();
		
		driver.close();
  }
}
