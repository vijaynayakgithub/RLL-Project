package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test9_ContactUs {
  @Test
  public void ContactUsTest() throws InterruptedException {
	  
	//Setting up the driver and getting the website
	    String driver_path="D:\\phase 5\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driver_path);
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:4200/user");
		
		WebElement contactUs = driver.findElement(By.xpath("/html/body/app-root/app-user/app-header/header/nav/a[3]"));
		contactUs.click();
		Thread.sleep(1000);
		
		WebElement name = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[1]/input"));
		name.sendKeys("Ria");
		
		WebElement mail = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[2]/input"));
		mail.sendKeys("ria@gmail.com");
		
		WebElement number = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[3]/input"));
		number.sendKeys("9658742112");
		
		WebElement desc = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[4]/input"));
		desc.sendKeys("The medicine is not in a good condition");
		
		WebElement submit = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/input"));
		submit.click();
		
		Thread.sleep(1000);
		WebElement confirm = driver.findElement(By.xpath("/html/body/div/div/div[6]/button[1]"));
		confirm.click();
		
		driver.close();
		
	  
  }
}
