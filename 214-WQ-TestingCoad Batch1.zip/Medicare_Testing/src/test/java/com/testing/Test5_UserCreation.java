package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test5_UserCreation {
  @Test
  public void createUser() throws InterruptedException {
	  
	    //Setting up the driver and getting the website
	    String driver_path="D:\\phase 5\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driver_path);
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:4200/user");
		
		//Clicking the new user to register new user
		WebElement newUserLink = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div/div/h3/a"));
		newUserLink.click();
		
		Thread.sleep(1000);
		
		//Sent the Required information
		WebElement firstName= driver.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/div[1]/input"));
		firstName.sendKeys("Amal");
		
		WebElement lastName= driver.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/div[2]/input"));
		lastName.sendKeys("Kannan");
		
		WebElement mobile= driver.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/div[3]/input"));
		mobile.sendKeys("9809448729");
		
		WebElement age= driver.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/div[4]/input"));
		age.sendKeys("22");
		
		WebElement username = driver.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/div[5]/input"));
		username.sendKeys("amalkannan");
		
		WebElement password = driver.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/div[6]/input"));
		password.sendKeys("Mamatha");
		
		WebElement gender = driver.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/div[7]/input"));
		gender.sendKeys("Male");
		
		
		WebElement submit = driver.findElement(By.xpath("/html/body/app-root/app-registration/div/div[2]/form/input"));
		submit.click();
		Thread.sleep(2000);
		WebElement confirm = driver.findElement(By.xpath("/html/body/div/div/div[6]/button[1]"));
		confirm.click();
		
		driver.close();
		
		
		
		
		
		
  }
}
