package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Test4_AdminMedicineDeletion {
  @Test
  public void medicineDelete() throws InterruptedException {
	//Setting up the driver and getting the website
	  String driver_path="D:\\phase 5\\ChromeDriver\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", driver_path);
		WebDriver driver = new ChromeDriver();
		driver.get("http://localhost:4200/user");
		//Clicking the admin link to go to admin login page
		WebElement adminLink = driver.findElement(By.xpath("/html/body/app-root/app-user/app-header/header/nav/a[1]"));
		adminLink.click();
		
		//Waiting to go to Admin page
		Thread.sleep(1000);
		//sending the user name
		WebElement username = driver.findElement(By.xpath("/html/body/app-root/app-admin/div/div/form/div/div/input[1]"));
		username.sendKeys("Akshay");
		
		//sending the password
		WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
		password.sendKeys("Krishna");
		
		//click Submit
		WebElement submit = driver.findElement(By.xpath("//*[@id=\"sect1\"]/div/form/div/div/input[3]"));
		submit.click();
		
		Thread.sleep(1000);
		
		WebElement confirm = driver.findElement(By.xpath("/html/body/div/div/div[6]/button[1]"));
		confirm.click();
		
		WebElement delete = driver.findElement(By.xpath("//*[@id=\"sect1\"]/div/div/table/tr[4]/td[10]/button"));
		delete.click();
		
		
		driver.close();
		
  }
}
