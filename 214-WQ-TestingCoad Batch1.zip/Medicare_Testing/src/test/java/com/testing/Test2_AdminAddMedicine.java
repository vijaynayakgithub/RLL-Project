package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
public class Test2_AdminAddMedicine {
	  @Test
	  public void AddMedicine() throws InterruptedException {
		  
		//Setting up the driver and getting the website
		  String driver_path="D:\\phase 5\\ChromeDriver\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", driver_path);
			WebDriver driver = new ChromeDriver();
			driver.get("http://localhost:4200/user");
			//Clicking the admin link to go to admin login page
			WebElement adminLink = driver.findElement(By.xpath("/html/body/app-root/app-user/app-header/header/nav/a[1]"));
			adminLink.click();
			
			//Waiting to go to Admin page
			Thread.sleep(1000);
			//sending the user name
			WebElement username = driver.findElement(By.xpath("/html/body/app-root/app-admin/div/div/form/div/div/input[1]"));
			username.sendKeys("Akshay");
			
			//sending the password
			WebElement password = driver.findElement(By.xpath("//*[@id=\"password\"]"));
			password.sendKeys("Krishna");
			
			//click Submit
			WebElement submit = driver.findElement(By.xpath("//*[@id=\"sect1\"]/div/form/div/div/input[3]"));
			submit.click();
			
			Thread.sleep(3000);
			
			WebElement confirm = driver.findElement(By.xpath("/html/body/div/div/div[6]/button[1]"));
			confirm.click();
			
			WebElement addMedicine = driver.findElement(By.xpath("//*[@id=\"sect1\"]/header/nav/a[1]"));
			addMedicine.click();
			
			Thread.sleep(1000);
			
			
			WebElement medicineName = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[1]/input"));
			medicineName.sendKeys("Dolo 650");
			
			WebElement manDate = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[2]/input"));
			manDate.sendKeys("30-03-2022");

			
			WebElement type = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[3]/input"));
			type.sendKeys("Tablet");
			
			WebElement price = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[4]/input"));
			price.sendKeys("10");

			
			WebElement desc = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[5]/input"));
			desc.sendKeys("Dolo-650 Tablet is the most widely used over-the-counter (OTC) medication.");
			
			
			WebElement expdate = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[6]/input"));
			expdate.sendKeys("30-03-2025");

			
			WebElement sts = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[7]/input"));
			sts.sendKeys("Available");
			
			WebElement seller = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/div[8]/input"));
			seller.sendKeys("Micro Labs Ltd.");
			
			submit = driver.findElement(By.xpath("//*[@id=\"sect1\"]/form/input"));
			submit.click();
			
			driver.close();
			
			
			
	  }
	}
